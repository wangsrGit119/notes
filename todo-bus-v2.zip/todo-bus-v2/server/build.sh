docker build -t todo-bus-app:1.0 .
