from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import sqlite3
import hashlib
import os
import json
from datetime import datetime
import re
import uvicorn

app = FastAPI()

# CORS设置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'xls', 'xlsx'}

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# 挂载静态文件
app.mount("/static", StaticFiles(directory="dist/static"), name="static")

ADMIN_KEY = 'admin'
ADMIN_PASSWORD = hashlib.md5('admin123'.encode()).hexdigest()

# Pydantic模型
class LoginRequest(BaseModel):
    keyNumber: str
    password: str

class RegisterRequest(BaseModel):
    keyNumber: str
    name: str
    intranetNumber: str
    departmentLevel1: str
    departmentLevel2: str
    password: str

class AppointmentRequest(BaseModel):
    userId: int
    clerkId: int
    appointmentDate: str
    appointmentTime: str
    content: str
    businessType: Optional[str] = None
    attachments: List[dict] = []

class CompleteRequest(BaseModel):
    feedback: str = ""

class RoleRequest(BaseModel):
    role: str
    businessTypes: str = ""

class ModifyUserRequest(BaseModel):
    userId: int
    keyNumber: Optional[str] = None
    name: Optional[str] = None
    intranetNumber: Optional[str] = None
    departmentLevel1: Optional[str] = None
    departmentLevel2: Optional[str] = None
    password: Optional[str] = None

class DepartmentRequest(BaseModel):
    level1Name: str
    level2Name: str = ""

def get_db():
    conn = sqlite3.connect('todo_bus.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    
    # 用户表
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key_number TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            intranet_number TEXT NOT NULL,
            department_level1 TEXT NOT NULL,
            department_level2 TEXT NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            business_types TEXT DEFAULT '',
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 用户信息修改申请表
    c.execute('''
        CREATE TABLE IF NOT EXISTS user_modifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            key_number TEXT,
            name TEXT,
            intranet_number TEXT,
            department_level1 TEXT,
            department_level2 TEXT,
            password TEXT,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # 预约表
    c.execute('''
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            clerk_id INTEGER,
            appointment_date TEXT NOT NULL,
            appointment_time TEXT NOT NULL,
            content TEXT NOT NULL,
            business_type TEXT,
            attachments TEXT,
            status TEXT DEFAULT 'pending',
            accepted_at TIMESTAMP,
            completed_at TIMESTAMP,
            feedback TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (clerk_id) REFERENCES users (id)
        )
    ''')
    
    # 部门配置表
    c.execute('''
        CREATE TABLE IF NOT EXISTS departments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            level1_name TEXT NOT NULL,
            level2_name TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 插入默认部门数据
    c.execute('SELECT COUNT(*) as count FROM departments')
    if c.fetchone()['count'] == 0:
        default_depts = [
            ('办公室', '综合科'),
            ('办公室', '行政科'),
            ('人事处', '人事科'),
            ('人事处', '培训科'),
            ('财务处', '会计科'),
            ('财务处', '审计科'),
            ('业务处', '业务一科'),
            ('业务处', '业务二科'),
            ('技术处', '技术支持科'),
            ('技术处', '研发科'),
            ('后勤处', '总务科'),
            ('后勤处', '安保科')
        ]
        c.executemany('INSERT INTO departments (level1_name, level2_name) VALUES (?, ?)', default_depts)
    
    conn.commit()
    conn.close()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.get("/", response_class=HTMLResponse)
async def read_root():
    with open("dist/index.html", "r", encoding="utf-8") as f:
        return f.read()

@app.post('/api/register')
async def register(data: RegisterRequest):
    key_number = data.keyNumber
    name = data.name
    intranet_number = data.intranetNumber
    department_level1 = data.departmentLevel1
    department_level2 = data.departmentLevel2
    password = data.password
    
    # 验证格式
    if not re.match(r'^[a-zA-Z]{3}\d{5}$', key_number):
        return {'success': False, 'message': 'Key号格式错误，应为3个英文字母加5个数字'}
    
    if not re.match(r'^\d{4}$', intranet_number):
        return {'success': False, 'message': '专网号格式错误，应为4位数字'}
    
    if not re.match(r'^\d{8}$', password):
        return {'success': False, 'message': '密码格式错误，应为8位数字'}
    
    conn = get_db()
    c = conn.cursor()
    
    # 检查key号是否已存在
    c.execute('SELECT * FROM users WHERE key_number = ?', (key_number,))
    if c.fetchone():
        conn.close()
        return {'success': False, 'message': 'Key号已存在'}
    
    # 插入新用户
    hashed_password = hashlib.md5(password.encode()).hexdigest()
    c.execute('''
        INSERT INTO users (key_number, name, intranet_number, department_level1, department_level2, password)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (key_number, name, intranet_number, department_level1, department_level2, hashed_password))
    
    conn.commit()
    conn.close()
    
    return {'success': True, 'message': '注册成功，等待管理员审核'}

@app.post('/api/login')
async def login(data: LoginRequest):
    key_number = data.keyNumber
    password = data.password
    
    # 检查是否为管理员账号
    if key_number == ADMIN_KEY:
        hashed_password = hashlib.md5(password.encode()).hexdigest()
        if hashed_password == ADMIN_PASSWORD:
            return {
                'success': True,
                'user': {
                    'id': 0,
                    'keyNumber': 'admin',
                    'name': '管理员',
                    'role': 'admin'
                }
            }
        else:
            return {'success': False, 'message': '密码错误'}
    
    conn = get_db()
    c = conn.cursor()
    
    hashed_password = hashlib.md5(password.encode()).hexdigest()
    c.execute('SELECT * FROM users WHERE key_number = ? AND password = ?', (key_number, hashed_password))
    user = c.fetchone()
    
    conn.close()
    
    if not user:
        return {'success': False, 'message': 'Key号或密码错误'}
    
    if user['status'] != 'approved':
        return {'success': False, 'message': '账号尚未通过审核'}
    
    return {
        'success': True,
        'user': {
            'id': user['id'],
            'keyNumber': user['key_number'],
            'name': user['name'],
            'intranetNumber': user['intranet_number'],
            'departmentLevel1': user['department_level1'],
            'departmentLevel2': user['department_level2'],
            'role': user['role'],
            'businessTypes': user['business_types']
        }
    }

@app.post('/api/upload')
async def upload_file(file: UploadFile = File(...)):
    if not file.filename:
        return {'success': False, 'message': '没有选择文件'}
    
    if file and allowed_file(file.filename):
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        filename = f"{timestamp}_{file.filename}"
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        
        with open(filepath, "wb") as buffer:
            content = await file.read()
            buffer.write(content)
        
        return {'success': True, 'filename': filename}
    
    return {'success': False, 'message': '不支持的文件类型'}

@app.get('/api/download/{filename}')
async def download_file(filename: str):
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    if os.path.exists(filepath):
        return FileResponse(filepath)
    raise HTTPException(status_code=404, detail="File not found")

@app.post('/api/appointments')
async def create_appointment(data: AppointmentRequest):
    user_id = data.userId
    clerk_id = data.clerkId
    appointment_date = data.appointmentDate
    appointment_time = data.appointmentTime
    content = data.content
    business_type = data.businessType
    attachments = json.dumps(data.attachments)
    
    conn = get_db()
    c = conn.cursor()
    
    c.execute('''
        INSERT INTO appointments (user_id, clerk_id, appointment_date, appointment_time, content, business_type, attachments)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (user_id, clerk_id, appointment_date, appointment_time, content, business_type, attachments))
    
    conn.commit()
    conn.close()
    
    return {'success': True, 'message': '预约成功'}

@app.get('/api/appointments/user/{user_id}')
async def get_user_appointments(user_id: int):
    conn = get_db()
    c = conn.cursor()
    
    c.execute('''
        SELECT a.*, u.name as clerk_name
        FROM appointments a
        LEFT JOIN users u ON a.clerk_id = u.id
        WHERE a.user_id = ?
        ORDER BY a.created_at DESC
    ''', (user_id,))
    
    appointments = [dict(row) for row in c.fetchall()]
    conn.close()
    
    for apt in appointments:
        if apt['attachments']:
            apt['attachments'] = json.loads(apt['attachments'])
    
    return {'success': True, 'appointments': appointments}

@app.get('/api/appointments/clerk/{clerk_id}')
async def get_clerk_appointments(clerk_id: int):
    conn = get_db()
    c = conn.cursor()
    
    c.execute('''
        SELECT a.*, u.name as user_name, u.intranet_number, u.department_level1, u.department_level2
        FROM appointments a
        JOIN users u ON a.user_id = u.id
        WHERE a.clerk_id = ?
        ORDER BY a.appointment_date, a.appointment_time
    ''', (clerk_id,))
    
    appointments = [dict(row) for row in c.fetchall()]
    conn.close()
    
    for apt in appointments:
        if apt['attachments']:
            apt['attachments'] = json.loads(apt['attachments'])
    
    return {'success': True, 'appointments': appointments}

@app.post('/api/appointments/{appointment_id}/accept')
async def accept_appointment(appointment_id: int):
    conn = get_db()
    c = conn.cursor()
    
    c.execute('''
        UPDATE appointments
        SET status = 'accepted', accepted_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ''', (appointment_id,))
    
    conn.commit()
    conn.close()
    
    return {'success': True, 'message': '已接受任务'}

@app.post('/api/appointments/{appointment_id}/complete')
async def complete_appointment(appointment_id: int, data: CompleteRequest):
    feedback = data.feedback
    
    conn = get_db()
    c = conn.cursor()
    
    c.execute('''
        UPDATE appointments
        SET status = 'completed', completed_at = CURRENT_TIMESTAMP, feedback = ?
        WHERE id = ?
    ''', (feedback, appointment_id))
    
    conn.commit()
    conn.close()
    
    return {'success': True, 'message': '已完成任务'}

@app.get('/api/clerks')
async def get_clerks():
    conn = get_db()
    c = conn.cursor()
    
    c.execute('''
        SELECT id, key_number, name, department_level1, department_level2, business_types
        FROM users
        WHERE role = 'clerk' AND status = 'approved'
    ''')
    
    clerks = [dict(row) for row in c.fetchall()]
    conn.close()
    
    return {'success': True, 'clerks': clerks}

@app.get('/api/clerks/{clerk_id}/schedule')
async def get_clerk_schedule(clerk_id: int, date: str):
    
    conn = get_db()
    c = conn.cursor()
    
    c.execute('''
        SELECT appointment_time
        FROM appointments
        WHERE clerk_id = ? AND appointment_date = ? AND status != 'completed'
    ''', (clerk_id, date))
    
    times = [row['appointment_time'] for row in c.fetchall()]
    conn.close()
    
    return {'success': True, 'bookedTimes': times}

@app.get('/api/admin/users')
async def get_all_users():
    conn = get_db()
    c = conn.cursor()
    
    c.execute('SELECT * FROM users ORDER BY created_at DESC')
    users = [dict(row) for row in c.fetchall()]
    
    conn.close()
    
    return {'success': True, 'users': users}

@app.post('/api/admin/users/{user_id}/approve')
async def approve_user(user_id: int):
    conn = get_db()
    c = conn.cursor()
    
    c.execute('UPDATE users SET status = ? WHERE id = ?', ('approved', user_id))
    
    conn.commit()
    conn.close()
    
    return {'success': True, 'message': '已批准用户'}

@app.post('/api/admin/users/{user_id}/reject')
async def reject_user(user_id: int):
    conn = get_db()
    c = conn.cursor()
    
    c.execute('UPDATE users SET status = ? WHERE id = ?', ('rejected', user_id))
    
    conn.commit()
    conn.close()
    
    return {'success': True, 'message': '已拒绝用户'}

@app.post('/api/admin/users/{user_id}/role')
async def set_user_role(user_id: int, data: RoleRequest):
    role = data.role
    business_types = data.businessTypes
    
    conn = get_db()
    c = conn.cursor()
    
    c.execute('UPDATE users SET role = ?, business_types = ? WHERE id = ?', (role, business_types, user_id))
    
    conn.commit()
    conn.close()
    
    return {'success': True, 'message': '已更新用户角色'}

@app.post('/api/user/modify')
async def modify_user_info(data: ModifyUserRequest):
    user_id = data.userId
    
    conn = get_db()
    c = conn.cursor()
    
    c.execute('''
        INSERT INTO user_modifications (user_id, key_number, name, intranet_number, department_level1, department_level2, password)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        user_id,
        data.keyNumber,
        data.name,
        data.intranetNumber,
        data.departmentLevel1,
        data.departmentLevel2,
        hashlib.md5(data.password.encode()).hexdigest() if data.password else None
    ))
    
    conn.commit()
    conn.close()
    
    return {'success': True, 'message': '修改申请已提交，等待管理员审核'}

@app.get('/api/admin/modifications')
async def get_modifications():
    conn = get_db()
    c = conn.cursor()
    
    c.execute('''
        SELECT m.*, u.key_number as current_key, u.name as current_name
        FROM user_modifications m
        JOIN users u ON m.user_id = u.id
        WHERE m.status = 'pending'
        ORDER BY m.created_at DESC
    ''')
    
    modifications = [dict(row) for row in c.fetchall()]
    conn.close()
    
    return {'success': True, 'modifications': modifications}

@app.post('/api/admin/modifications/{mod_id}/approve')
async def approve_modification(mod_id: int):
    conn = get_db()
    c = conn.cursor()
    
    c.execute('SELECT * FROM user_modifications WHERE id = ?', (mod_id,))
    mod = c.fetchone()
    
    if mod:
        updates = []
        params = []
        
        if mod['key_number']:
            updates.append('key_number = ?')
            params.append(mod['key_number'])
        if mod['name']:
            updates.append('name = ?')
            params.append(mod['name'])
        if mod['intranet_number']:
            updates.append('intranet_number = ?')
            params.append(mod['intranet_number'])
        if mod['department_level1']:
            updates.append('department_level1 = ?')
            params.append(mod['department_level1'])
        if mod['department_level2']:
            updates.append('department_level2 = ?')
            params.append(mod['department_level2'])
        if mod['password']:
            updates.append('password = ?')
            params.append(mod['password'])
        
        params.append(mod['user_id'])
        
        if updates:
            c.execute(f"UPDATE users SET {', '.join(updates)} WHERE id = ?", params)
        
        c.execute('UPDATE user_modifications SET status = ? WHERE id = ?', ('approved', mod_id))
    
    conn.commit()
    conn.close()
    
    return {'success': True, 'message': '已批准修改申请'}

@app.post('/api/admin/modifications/{mod_id}/reject')
async def reject_modification(mod_id: int):
    conn = get_db()
    c = conn.cursor()
    
    c.execute('UPDATE user_modifications SET status = ? WHERE id = ?', ('rejected', mod_id))
    
    conn.commit()
    conn.close()
    
    return {'success': True, 'message': '已拒绝修改申请'}

@app.get('/api/user/{user_id}/modification-status')
async def get_modification_status(user_id: int):
    conn = get_db()
    c = conn.cursor()
    
    c.execute('''
        SELECT status FROM user_modifications
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 1
    ''', (user_id,))
    
    result = c.fetchone()
    conn.close()
    
    status = result['status'] if result else None
    return {'success': True, 'status': status}

@app.get('/api/departments')
async def get_departments():
    conn = get_db()
    c = conn.cursor()
    
    c.execute('SELECT * FROM departments ORDER BY level1_name, level2_name')
    departments = [dict(row) for row in c.fetchall()]
    
    conn.close()
    
    # 按处室分组
    dept_dict = {}
    for dept in departments:
        level1 = dept['level1_name']
        if level1 not in dept_dict:
            dept_dict[level1] = []
        if dept['level2_name']:
            dept_dict[level1].append(dept['level2_name'])
    
    return {'success': True, 'departments': dept_dict, 'all': departments}

@app.post('/api/admin/departments')
async def add_department(data: DepartmentRequest):
    conn = get_db()
    c = conn.cursor()
    
    c.execute('INSERT INTO departments (level1_name, level2_name) VALUES (?, ?)',
              (data.level1Name, data.level2Name))
    
    conn.commit()
    conn.close()
    
    return {'success': True, 'message': '部门添加成功'}

@app.delete('/api/admin/departments/{dept_id}')
async def delete_department(dept_id: int):
    conn = get_db()
    c = conn.cursor()
    
    c.execute('DELETE FROM departments WHERE id = ?', (dept_id,))
    
    conn.commit()
    conn.close()
    
    return {'success': True, 'message': '部门删除成功'}

if __name__ == '__main__':
    init_db()
    uvicorn.run(app, host='0.0.0.0', port=25000)