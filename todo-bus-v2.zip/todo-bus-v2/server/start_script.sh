#!/bin/bash

# Todo-Bus Docker 控制脚本
# 用法: sh start_script.sh [start|stop|restart|logs|status]

SERVICE_NAME="todo-bus"
COMPOSE_FILE="docker-compose.yml"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 打印带颜色的消息
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# 启动服务
start_service() {
    print_info "正在启动 ${SERVICE_NAME} 服务..."
    docker-compose -f ${COMPOSE_FILE} up -d
    
    if [ $? -eq 0 ]; then
        print_info "${SERVICE_NAME} 服务启动成功！"
        print_info "访问地址: http://localhost:25000"
    else
        print_error "${SERVICE_NAME} 服务启动失败！"
        exit 1
    fi
}

# 停止服务
stop_service() {
    print_info "正在停止 ${SERVICE_NAME} 服务..."
    docker-compose -f ${COMPOSE_FILE} down
    
    if [ $? -eq 0 ]; then
        print_info "${SERVICE_NAME} 服务已停止"
    else
        print_error "${SERVICE_NAME} 服务停止失败！"
        exit 1
    fi
}

# 重启服务
restart_service() {
    print_info "正在重启 ${SERVICE_NAME} 服务..."
    docker-compose -f ${COMPOSE_FILE} restart
    
    if [ $? -eq 0 ]; then
        print_info "${SERVICE_NAME} 服务重启成功！"
    else
        print_error "${SERVICE_NAME} 服务重启失败！"
        exit 1
    fi
}

# 查看日志
view_logs() {
    print_info "查看 ${SERVICE_NAME} 服务日志 (按 Ctrl+C 退出)..."
    docker-compose -f ${COMPOSE_FILE} logs -f --tail=100
}

# 查看服务状态
check_status() {
    print_info "${SERVICE_NAME} 服务状态:"
    docker-compose -f ${COMPOSE_FILE} ps
    
    echo ""
    print_info "容器详细信息:"
    docker ps --filter "name=${SERVICE_NAME}" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
}

# 显示使用帮助
show_help() {
    echo "用法: sh start_script.sh [COMMAND]"
    echo ""
    echo "可用命令:"
    echo "  start    - 启动服务"
    echo "  stop     - 停止服务"
    echo "  restart  - 重启服务"
    echo "  logs     - 查看服务日志"
    echo "  status   - 查看服务状态"
    echo ""
    echo "其他命令:"
    echo "  构建镜像: sh build.sh"
    echo ""
    echo "示例:"
    echo "  sh start_script.sh start"
    echo "  sh start_script.sh logs"
}

# 主函数
main() {

    
    # 获取命令参数
    COMMAND=$1
    
    case "$COMMAND" in
        start)
            start_service
            ;;
        stop)
            stop_service
            ;;
        restart)
            restart_service
            ;;
        logs)
            view_logs
            ;;
        status)
            check_status
            ;;
        "")
            print_error "请指定命令！"
            echo ""
            show_help
            exit 1
            ;;
        *)
            print_error "未知命令: $COMMAND"
            echo ""
            show_help
            exit 1
            ;;
    esac
}

# 执行主函数
main $@